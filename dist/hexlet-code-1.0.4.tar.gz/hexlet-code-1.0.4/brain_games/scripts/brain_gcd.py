#!/usr/bin/env python
from brain_games.logic.brain_gcd_game import brain_gcd_game


def main():
    brain_gcd_game()


if __name__ == '__main__':
    main()
