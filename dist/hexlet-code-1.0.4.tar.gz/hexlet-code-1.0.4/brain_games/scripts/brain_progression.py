#!/usr/bin/env python
from brain_games.logic.brain_progression_game import brain_progression_game


def main():
    brain_progression_game()


if __name__ == '__main__':
    main()
