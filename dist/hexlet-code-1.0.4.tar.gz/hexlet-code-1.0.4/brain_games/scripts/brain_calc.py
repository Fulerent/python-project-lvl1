#!/usr/bin/env python
from brain_games.logic.brain_calc_game import brain_calc_game


def main():
    brain_calc_game()


if __name__ == '__main__':
    main()
