#!/usr/bin/env python
from brain_games.logic.brain_even_game import brain_even_game


def main():
    brain_even_game()


if __name__ == '__main__':
    main()
