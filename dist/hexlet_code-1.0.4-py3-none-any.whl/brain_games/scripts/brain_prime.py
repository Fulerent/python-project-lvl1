#!/usr/bin/env python
from brain_games.logic.brain_prime_game import brain_prime_game


def main():
    brain_prime_game()


if __name__ == '__main__':
    main()
